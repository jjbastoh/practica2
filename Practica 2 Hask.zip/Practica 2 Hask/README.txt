Practica 2 Lenguajes de Programación
Integrantes: 
Juan José Basto Hormaza
David Restrepo Aristizábal
Enlace GITHUB: